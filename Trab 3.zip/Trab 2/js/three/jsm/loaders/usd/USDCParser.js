import {
	Group
} from 'three';

class USDCParser {

	parse( buffer ) {

		// TODO

		return new Group();

	}

}

export { USDCParser };
